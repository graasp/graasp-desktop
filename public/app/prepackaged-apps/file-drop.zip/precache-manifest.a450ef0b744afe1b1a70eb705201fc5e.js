self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b44222b3016cbe4ea81c6e81e3f0b3ad",
    "url": "./index.html"
  },
  {
    "revision": "20f9775591dff2bf56a3",
    "url": "./static/css/2.961f374f.chunk.css"
  },
  {
    "revision": "8b1bc371d946acbf5ee3",
    "url": "./static/css/main.8e8450fa.chunk.css"
  },
  {
    "revision": "20f9775591dff2bf56a3",
    "url": "./static/js/2.acb8ca50.chunk.js"
  },
  {
    "revision": "8b1bc371d946acbf5ee3",
    "url": "./static/js/main.896e9103.chunk.js"
  },
  {
    "revision": "325cd71afa6716e3e43a",
    "url": "./static/js/runtime-main.745b462a.js"
  },
  {
    "revision": "613b5ab759d2f8d1d37e30a527b8bec9",
    "url": "./static/media/logo.613b5ab7.svg"
  }
]);